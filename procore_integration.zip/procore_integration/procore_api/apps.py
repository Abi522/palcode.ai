from django.apps import AppConfig


class ProcoreApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'procore_api'
